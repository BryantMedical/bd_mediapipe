opencv_version = "4.8.1.78"
contrib = True
headless = False
rolling = False
ci_build = True