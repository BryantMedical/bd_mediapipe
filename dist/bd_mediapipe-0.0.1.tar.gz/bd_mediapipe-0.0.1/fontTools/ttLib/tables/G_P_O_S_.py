from .otBase import BaseTTXConverter


class table_G_P_O_S_(BaseTTXConverter):
    pass
