from fontTools import ttLib

superclass = ttLib.getTableClass("fpgm")


class table__p_r_e_p(superclass):
    pass
